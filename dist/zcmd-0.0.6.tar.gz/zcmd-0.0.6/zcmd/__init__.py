from .zcmd import *

__version__ = (0, 7)